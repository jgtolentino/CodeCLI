#!/bin/bash
source .env
npx codex "$@"
