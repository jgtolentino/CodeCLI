const fs = require('fs');
const path = require('path');
const Mustache = require('mustache');

const data = JSON.parse(fs.readFileSync('mysite/data/data.json', 'utf8'));
const template = fs.readFileSync('mysite/template/index.mustache', 'utf8');
const output = Mustache.render(template, data);

const outDir = 'mysite/out';
if (!fs.existsSync(outDir)) fs.mkdirSync(outDir);
fs.writeFileSync(path.join(outDir, 'index.html'), output);
console.log('✅ Build complete');
