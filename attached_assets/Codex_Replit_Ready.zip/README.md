# Codex Static Site Generator (Replit Ready)

## 📁 Structure

- `mysite/data/data.json` - your content
- `mysite/template/index.mustache` - your HTML template
- `mysite/out/index.html` - output (generated)
- `build.js` - builds HTML from JSON + Mustache
- `serve.js` - serves static HTML on port 1227

## 🚀 Usage on Replit

### 1. Install dependencies:
```
npm install mustache express
```

### 2. Build your site:
```
node build.js
```

### 3. Serve the site:
```
node serve.js
```

Visit `https://<your-replit-url>.repl.co` to see it live!
